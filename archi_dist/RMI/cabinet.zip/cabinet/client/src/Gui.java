//import javax.swing.*;
//import java.awt.*;
//
//public class Gui implements Runnable{
//    JFrame mainFrame = new JFrame("Cabinet Veterinaire");
////    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//    // App's Toolbar
//    JToolBar toolbar = new JToolBar();
//    toolbar.setRollover(true);
//    JButton list  = new JButton("Lister patient");
//    toolbar.add(list);
//    JButton add  = new JButton("Ajouter");
//    toolbar.add(add);
//    JButton search  = new JButton("Rechercher");
//    toolbar.add(search);
//    JButton delete  = new JButton("Supprimer un patient");
//    toolbar.add(delete);
//    //
//    Container contentPane = mainFrame.getContentPane();
//    contentPane.add(toolbar);
//    /**
//     * When an object implementing interface <code>Runnable</code> is used
//     * to create a thread, starting the thread causes the object's
//     * <code>run</code> method to be called in that separately executing
//     * thread.
//     * <p>
//     * The general contract of the method <code>run</code> is that it may
//     * take any action whatsoever.
//     *
//     * @see Thread#run()
//     */
//    @Override
//    public void run() {
//
//    }
//}
