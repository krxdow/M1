ajouté un uml du projet


Il faut prévoir une procédure d’arrêt avec arrêt des
objets distants :

revoire le gestionnaire de securité

• Il faut prévoir une procédure d’arrêt avec arrêt des objets distants :
• public static void Naming.unbind(String name)
• public static boolean UnicastRemoteObject.unexportObject(Remote,boolean force